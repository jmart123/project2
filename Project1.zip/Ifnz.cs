using System;

class Ifnz : Instruction {

	//1-arg constructor
	public Ifnz (int parameter) {
		this.Parameter = (uint)parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)9 << 28;  

			//ifnz COND is 1
			instruction |= (uint)1 << 24;
			
			//parameter goes in the other 24 bits
			instruction |= (Parameter << 8) >> 8; 
			
			return instruction;
		}
	}
}
