using System;

class Print : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)13 << 28;  

			//parameter is always 0

			return instruction;
		}
	}
}
