using System;

class Mul : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)34 << 24;  

			return instruction;
		}
	}
}
