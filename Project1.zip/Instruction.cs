using System;

//Intruction will be inherited by each instruction
public abstract class Instruction {
	
	private uint parameter;
	
	public uint Parameter {
		set { parameter = value; }

		get { return parameter; }
	}

	//will be overridden by subclass
	public virtual uint Encode { 
		get; 
	}
}
