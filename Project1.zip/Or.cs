using System;

class Or : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)38 << 24;

			//parameter is always 0
			
			return instruction;
		}
	}
}
