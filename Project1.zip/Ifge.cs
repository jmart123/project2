using System;

class Ifge : Instruction {

	//1-arg constructor
	public Ifge (int parameter) {
		this.Parameter = (uint)parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)8 << 28;  

			//ifge COND is 5
			instruction |= (uint)5 << 24;
			
			//parameter goes in the other 24 bits
			instruction |= (Parameter << 8) >> 8; 
			
			return instruction;
		}
	}
}
