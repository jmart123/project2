using System;

class Add : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left, rest is 0
			instruction = (uint)2 << 28;
			
			return instruction;
		}
	}
}
