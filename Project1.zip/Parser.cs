using System;
using System.IO;
using System.Collections.Generic;

class Parser {
	public List<string> file;
	public Dictionary<string, int> labels;

	public Parser() { //Default Constructor
		file = new List<string>();
		labels = new Dictionary<string, int>();
	}

	public Parser(string fname) { //Constructor
		string[] fileTemp = Read(fname);
		file = new List<string>(fileTemp);
		labels = new Dictionary<string, int>();
	}

	public string[] Read(string filename) {
		// Read each line of the file into a string array. Each element
		// of the array is one line of the file.
		try {
			string[] lines = System.IO.File.ReadAllLines(@filename);
			return lines;
		}
		catch {
			Console.WriteLine("Invalid Filename");
			string[] empty = new string[0];
			return empty;
		}
	}

	public void Parse() {
		int i;
		string[] split;
		int convertedHex;

		int address = 0;
		for(i = 0; i < file.Count; i++) { //Loop through file lines
			file[i] = file[i].TrimStart(); //Remove white space left of line
			file[i] = file[i].ToLower(); //Ignore case
			for(int j = 0; j < file[i].Length; j++) {
				if(file[i][j] == '/') {
					int index = file[i].IndexOf("//");
					file[i] = file[i].Substring(0, index);
					break;
				}
			}

			if(string.IsNullOrEmpty(file[i])) {
				//Ignore blank lines
				file.RemoveAt(i);
				i--; //decrement so an element is not skipped
			} else if(file[i].Contains(":")) { 
				//Label found. Add to dictionary and remove from file lines
				file[i] = file[i].Replace(":", "");
				labels.Add(file[i], address);
				file.RemoveAt(i);
				i--;
			} else {
				//Instruction line
				split = file[i].Split(new char[0], StringSplitOptions.RemoveEmptyEntries); //Split strings by whitespace
				if((split[0].Equals("push") || split[0].Equals("exit")) && split.Length < 2) {
					string[] temp = new string[2];
					temp[0] = split[0];
					temp[1] = "0";
					split = temp;
				}

				if(file[i].Contains("0x")) {
					for(int j = 0; j < split.Length; j++) {
						if(split[j].Contains("0x")) { //Change hex to decimal
							split[j] = split[j].Replace("0x", "");
							convertedHex = Convert.ToInt32(split[j], 16);
							split[j] = convertedHex.ToString();
						}
					}
				}
				if(split.Length < 2) {
					file[i] = split[0];
				} else {
					for(int j = 0; j < split.Length; j++) {
						if(split[j].Equals("") && ((j + 1) < split.Length)) {
							split[j] = split[j+1];
						}
					}
					
					file[i] = split[0] + " " + split[1]; //Combine strings
				}
				address += 4; //Each instruction is 4 bytes
			}
		}

		//Replace instructions with decimal addresses
		for(i = 0; i < file.Count; i++) {
			foreach(KeyValuePair<string, int> entry in labels) {
				if(file[i].Contains(entry.Key)) {
					split = file[i].Split(null);
					file[i] = split[0];
					for(int j = 1; j < split.Length; j++) {
						if(split[j].Contains(entry.Key)) {
							split[j] = split[j].Replace(entry.Key, (entry.Value).ToString());
						}
						else if(split[j].Equals("")) {
							continue;
						}
						file[i] = file[i] + " " + split[j];
					}
				}
			}
		}
		return; 
	}

	public void Add(string appendString) {
		file.Add(appendString);
		return;
	}
}
