using System;

class Push : Instruction {

	//1-arg constructor
	public Push (int parameter) {
		this.Parameter = (uint)parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)15 << 28;  

			//parameter goes in the other 28 bits
			instruction |= (uint)Parameter; 
			
			return instruction;
		}
	}
}
