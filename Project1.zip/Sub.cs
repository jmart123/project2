using System;

class Sub : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left, rest is 0
			instruction = (uint)33 << 24;  
			
			return instruction;
		}
	}
}
