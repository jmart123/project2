using System;

class Div : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)35 << 24;

			//parameter is always 0
			
			return instruction;
		}
	}
}
