/*
	CS365 Project 1

	Group members:
	Gurudev Ball-Khalsa
	Alex Nehls
	Tristan Spakes
	Robert McNeil
*/
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

class Driver {
	
	static void Main(string [] args) {
		
		Parser P; 
		List<Instruction> I;

		if (args.Length != 1) {
			Console.WriteLine("Usage: mono Assembler filename.asm");
			throw new Exception("Invalid Arguments");
		} else {
			P = new Parser(args[0]);
		}
		
		//Parser also has an Add() method which incrementally builds the 
		//instruction list instead of reading from the file. 
		//The Parser(string filename) constructor reads from filename
		//line-by-line into a List<string>

		P.Parse();

		I = Assembler.Assemble(P.file);
		
		using (var BW = new BinaryWriter(File.OpenWrite("out.bin"))) {
			BW.Write(0xefbeedfe);
			I.ForEach(i => { BW.Write(i.Encode); } );
		}
	}	
}
