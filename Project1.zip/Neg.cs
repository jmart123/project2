using System;

class Neg : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)3 << 28;

			//parameter is always 0
			
			return instruction;
		}
	}
}
