using System;

class Exit : Instruction {

	//1-arg constructor
	public Exit (uint parameter) {
		this.Parameter = parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;   

			//Op code is 0
			instruction = Parameter; 
			
			return instruction;
		}
	}
}
