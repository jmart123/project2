using System;

class Ifle : Instruction {

	//1-arg constructor
	public Ifle (int parameter) {
		this.Parameter = (uint)parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)8 << 28;  

			//ifle COND is 4
			instruction |= (uint)4 << 24;
			
			//parameter goes in the other 24 bits
			instruction |= (Parameter << 8) >> 8; 
			
			return instruction;
		}
	}
}
