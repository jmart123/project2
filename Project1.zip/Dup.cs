using System;

class Dup : Instruction {

	//1-arg constructor
	public Dup (int parameter) {
		this.Parameter = (uint)parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)12 << 28;  

			//parameter goes in the other 28 bits
			instruction |= Parameter; 
			
			return instruction;
		}
	}
}
