using System;

class Nop : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction = 0;
			
			//opcode goes all the way to the left, rest is 0
			instruction |= (uint)3 << 24;  

			return instruction;
		}
	}
}
