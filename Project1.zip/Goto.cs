using System;

class Goto : Instruction {

	//1-arg constructor
	public Goto (int parameter) {
		this.Parameter = (uint)parameter;
	}

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)7 << 28;  

			//parameter goes in the other 28 bits
			instruction |= Parameter; 
			
			return instruction;
		}
	}
}
