using System;

class Inpt : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left, rest is 0
			instruction = (uint)2 << 24;  
			return instruction;
		}
	}
}
