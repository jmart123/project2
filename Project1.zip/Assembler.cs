using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

class Assembler {
	
	private static List<Instruction> I;

	public static List<Instruction> Assemble(List<string> S) {
		/*  
			takes a list of strings, where each string 
			is a line of instruction e.g. "push 4"
			
			for each instruction:
				parse to determine instruction type
				switch(type) {
					case "push":
						I.Add(new Push(4);
					...
				}

			return instruction list I
		*/
	
		I = new List<Instruction>();

		int InstructionCounter = 0;

		S.ForEach(s => {
			
			//split line into instruction + parameter
			string [] tmp = s.Split(null);

				//call constructor for specified instruction
				switch(tmp[0]) {
				
					case "push":
						I.Add(new Push(Int32.Parse(tmp[1])));
						break;
				
					case "pop":
						I.Add(new Pop());
						break;
				
					case "exit":
						I.Add(new Exit(UInt32.Parse(tmp[1])));
						break;
				
					case "swap":
						I.Add(new Swap());
						break;
				
					case "inpt":
						I.Add(new Inpt());
						break;
				
					case "nop":
						I.Add(new Nop());
						break;
				
					case "add":
						I.Add(new Add());
						break;
				
					case "sub":
						I.Add(new Sub());
						break;
				
					case "mul":
						I.Add(new Mul());
						break;
				
					case "div":
						I.Add(new Div());
						break;
				
					case "rem":
						I.Add(new Rem());
						break;
				
					case "and":
						I.Add(new And());
						break;
				
					case "or":
						I.Add(new Or());
						break;
				
					case "xor":
						I.Add(new Xor());
						break;
				
					case "neg":
						I.Add(new Neg());
						break;
				
					case "not":
						I.Add(new Not());
						break;
				
					case "goto":
						I.Add(new Goto(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
				
					case "ifeq":
						I.Add(new Ifeq(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
				
					case "ifne":
						I.Add(new Ifne(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "iflt":
						I.Add(new Iflt(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifgt":
						I.Add(new Ifgt(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifle":
						I.Add(new Ifle(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifge":
						I.Add(new Ifge(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifez":
						I.Add(new Ifez(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifnz":
						I.Add(new Ifnz(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifmi":
						I.Add(new Ifmi(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "ifpl":
						I.Add(new Ifpl(Int32.Parse(tmp[1])-(4*InstructionCounter)));
						break;
					
					case "dup":
						if (tmp.Length == 2) {
							I.Add(new Dup(4*Int32.Parse(tmp[1])));
						} else
							I.Add(new Dup(0));
						break;
					
					case "print":
						I.Add(new Print());
						break;
					
					case "dump":
						I.Add(new Dump());
						break;

					default:
						throw new Exception($"{tmp[0]}: invalid instruction");
			}
		
			InstructionCounter++;	
		});

		return I;
	}
}
