using System;

class Swap : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes to left, rest is 0
			instruction = (uint)1 << 24; 
			
			return instruction;
		}
	}
}
