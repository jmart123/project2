using System;

class And : Instruction {

	//Encode property override
	public override uint Encode {
		get {	

			uint instruction;
			
			//opcode goes all the way to the left
			instruction = (uint)37 << 24;

			//parameter is always 0
			
			return instruction;
		}
	}
}
